self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2cb38d23e29611277c9739a7d012070f",
    "url": "./index.html"
  },
  {
    "revision": "f4c27651080d92962c39",
    "url": "./static/css/main.931965f7.chunk.css"
  },
  {
    "revision": "c6b080086553f07dad43",
    "url": "./static/js/2.777a4ad7.chunk.js"
  },
  {
    "revision": "79f40f67452769243e69b178a6ada149",
    "url": "./static/js/2.777a4ad7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f4c27651080d92962c39",
    "url": "./static/js/main.27f89683.chunk.js"
  },
  {
    "revision": "e86c2ff2f1eb78554e57",
    "url": "./static/js/runtime-main.0660989e.js"
  }
]);